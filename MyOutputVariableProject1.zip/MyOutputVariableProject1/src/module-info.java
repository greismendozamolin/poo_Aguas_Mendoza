/**
 * 
 */
/**
 * 
 */
module MyOutputVariableProject1 {
}